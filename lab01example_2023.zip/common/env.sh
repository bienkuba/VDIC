source /cad/etc/lm_license_file
source /eda/cadence/2021-22/scripts/XCELIUM_21.03.009_RHELx86.sh
source /eda/cadence/2021-22/scripts/VMANAGER_21.03.003_RHELx86.sh
